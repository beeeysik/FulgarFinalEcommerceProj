import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainBodyComponent } from './main-body/main-body.component';
import { XboxComponent } from './xbox/xbox.component';
import { CompanyHomeComponent } from './company-home/company-home.component';
// Removed Cart, Order, Customer routes per request
import { ContactUsComponent } from './contact-us/contact-us.component';
import { ProductCategoryComponent } from './product-category/product-category.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';

const routes: Routes = [
  {path:'',component:MainBodyComponent},
  {path:'catalog',component:ProductCategoryComponent},
  {path:'product/:id',component:ProductDetailComponent},
  {path:'cart',component:ShoppingCartComponent},
  {path:'contact',component:ContactUsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
