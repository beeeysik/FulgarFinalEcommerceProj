import { Component, OnInit } from '@angular/core';
import { MenuService } from '../service/menu.service';
import { Menu } from '../model/menu';
import { ThemeService } from '../service/theme.service';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-header',
  standalone: false,
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit  {
  public menus: Menu[] = []
  public themeLabel = 'Dark mode';
  public isDark = false;
  public cartCount = 0;

  constructor(private menuService: MenuService, private theme: ThemeService, private cart: CartService) {
  }

  ngOnInit(): void {
      this.menuService.getData().subscribe(data => {this.menus = data; });
      // initialize theme and update label
      this.theme.init();
      this.updateThemeLabel();

      // load cart count
      this.cart.list().subscribe({
        next: (items) => {
          const total = (items || []).reduce((sum: number, it: any) => sum + Number(it.quantity || 0), 0);
          this.cartCount = total;
        },
        error: () => { this.cartCount = 0; }
      });
  }

  toggleTheme() {
    this.theme.toggle();
    this.updateThemeLabel();
  }

  onThemeSwitch(checked: boolean) {
    // Set explicit theme based on switch position to avoid double toggles
    this.theme.setTheme(checked ? 'dark' : 'light');
    this.updateThemeLabel();
  }

  private updateThemeLabel() {
    const mode = this.theme.current;
    this.themeLabel = mode === 'dark' ? 'Light mode' : 'Dark mode';
    this.isDark = mode === 'dark';
  }
}
