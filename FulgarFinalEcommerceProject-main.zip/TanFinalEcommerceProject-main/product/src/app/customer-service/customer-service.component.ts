import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-service',
  standalone: false,
  templateUrl: './customer-service.component.html',
  styleUrls: ['./customer-service.component.css']
})
export class CustomerServiceComponent {

}
