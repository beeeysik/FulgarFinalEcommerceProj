import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'product';
  pageTitle = 'Home';
  private sub?: Subscription;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.sub = this.router.events.subscribe(ev => {
      if (ev instanceof NavigationEnd) this.computeTitle();
    });
    this.computeTitle();
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  private computeTitle() {
    const url = this.router.url.split('?')[0];
    const seg = url.replace(/^\/*/, '').split('/')[0];
    const map: Record<string, string> = {
      '': 'Home',
      contact: 'Contact',
      employees: 'Employees',
      leave: 'Leave Management'
    };
    this.pageTitle = map[seg] ?? (seg ? (seg.charAt(0).toUpperCase() + seg.slice(1)) : 'Home');
  }
}
