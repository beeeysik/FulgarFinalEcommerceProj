import { Component, OnInit } from '@angular/core';
import { CartService } from '../service/cart.service';
import { forkJoin } from 'rxjs';
import { OrderService } from '../service/order.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shopping-cart',
  standalone: false,
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
  items: any[] = [];

  constructor(private cart: CartService, private orderService: OrderService, private router: Router) {}

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.cart.list().subscribe(items => this.items = items || []);
  }

  total(): number {
    return this.items.reduce((sum, it) => sum + Number(it.price) * Number(it.quantity), 0);
  }

  remove(id: number) {
    this.cart.remove(id).subscribe(() => this.load());
  }

  clear() {
    const ops = (this.items || []).map(it => this.cart.remove(it.id));
    if (!ops.length) return;
    forkJoin(ops).subscribe(() => this.load());
  }

  checkout() {
    if (!this.items || !this.items.length) return;
    const order = { items: this.items };
    // POST to backend /api/order
    this.orderService.add(order).subscribe(() => {
      // on success clear local cart (we already persisted items to DB) and navigate to confirmation
      this.cart.clearLocal().subscribe(() => {
        this.router.navigate(['/cart']);
        this.load();
      });
    }, err => {
      console.error('Checkout failed', err);
    });
  }
}
