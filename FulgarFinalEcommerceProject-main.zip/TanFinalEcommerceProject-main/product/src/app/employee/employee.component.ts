import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Employee } from '../model/employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-employee',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employees: Employee[] = [];

  model: Partial<Employee> = {};
  editing = false;
  filter = '';

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.employeeService.getAll().subscribe(list => this.employees = list);
  }

  get filteredEmployees(): Employee[] {
    const q = this.filter.trim().toLowerCase();
    const list = this.employees.slice().sort((a, b) => b.id - a.id);
    if (!q) return list;
    return list.filter(e =>
      `${e.firstName} ${e.lastName}`.toLowerCase().includes(q) ||
      e.email.toLowerCase().includes(q) ||
      (e.position || '').toLowerCase().includes(q)
    );
  }

  trackById(_index: number, e: Employee) { return e.id; }

  isEditing(e: Employee) { return this.editing && this.model?.id === e.id; }

  submit() {
    if (!this.model.firstName || !this.model.lastName || !this.model.email) return;

    if (this.editing && this.model.id) {
      this.employeeService.update(this.model as Employee);
    } else {
      this.employeeService.add({
        firstName: this.model.firstName!,
        lastName: this.model.lastName!,
        email: this.model.email!,
        position: this.model.position || ''
      });
    }

    this.resetForm();
  }

  edit(e: Employee) {
    this.model = { ...e };
    this.editing = true;
  }

  remove(id: number) {
    if (!confirm('Delete this employee?')) return;
    this.employeeService.delete(id);
    if (this.model && this.model.id === id) this.resetForm();
  }

  resetForm() {
    this.model = {};
    this.editing = false;
  }
}
