import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Observable, BehaviorSubject, combineLatest } from 'rxjs';
import { map } from 'rxjs/operators';
import { LeaveRequest, LeaveType, LeaveStatus } from '../model/leave';
import { LeaveService } from '../service/leave.service';

@Component({
  selector: 'app-leave',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './leave.component.html',
  styleUrls: ['./leave.component.css']
})
export class LeaveComponent {
  // form model
  form = {
    employeeName: '',
    type: 'Vacation' as LeaveType,
    startDate: '',
    endDate: '',
    reason: ''
  };

  leaves$!: Observable<LeaveRequest[]>;
  private search$ = new BehaviorSubject<string>('');
  private status$ = new BehaviorSubject<'All' | LeaveStatus>('All');
  private sort$ = new BehaviorSubject<'newest' | 'oldest'>('newest');
  searchTerm = '';
  statusFilter: 'All' | LeaveStatus = 'All';
  sortOrder: 'newest' | 'oldest' = 'newest';
  isEditingId: string | null = null;
  dateError: string | null = null;

  types: LeaveType[] = ['Vacation', 'Sick', 'Unpaid', 'Other'];

  constructor(private leave: LeaveService) {
    this.leaves$ = combineLatest([
      this.leave.list(),
      this.search$,
      this.status$,
      this.sort$
    ]).pipe(
      map(([list, q, status, sort]) => {
        const query = q.trim().toLowerCase();
        let out = list.filter(it => {
          const matchesText = !query ||
            it.employeeName.toLowerCase().includes(query) ||
            it.type.toLowerCase().includes(query) ||
            it.status.toLowerCase().includes(query) ||
            it.reason.toLowerCase().includes(query);
          const matchesStatus = status === 'All' || it.status === status;
          return matchesText && matchesStatus;
        });
        out = out.sort((a, b) => sort === 'newest' ? (b.createdAt - a.createdAt) : (a.createdAt - b.createdAt));
        return out;
      })
    );
  }

  onSearch(term: string) {
    this.searchTerm = term;
    this.search$.next(term);
  }

  onStatusChange(value: 'All' | LeaveStatus) {
    this.statusFilter = value;
    this.status$.next(value);
  }

  onSortChange(order: 'newest' | 'oldest') {
    this.sortOrder = order;
    this.sort$.next(order);
  }

  submit(f: NgForm) {
    if (!f.valid) return;
    // basic date validation
    this.dateError = null;
    if (this.form.startDate && this.form.endDate) {
      const s = new Date(this.form.startDate).getTime();
      const e = new Date(this.form.endDate).getTime();
      if (!isNaN(s) && !isNaN(e) && e < s) {
        this.dateError = 'End date cannot be earlier than start date.';
        return;
      }
    }
    if (this.isEditingId) {
      this.leave.update(this.isEditingId, { ...this.form });
      this.isEditingId = null;
    } else {
      this.leave.add({ ...this.form });
    }
    this.reset(f);
  }

  edit(item: LeaveRequest) {
    this.isEditingId = item.id;
    this.form = {
      employeeName: item.employeeName,
      type: item.type,
      startDate: item.startDate,
      endDate: item.endDate,
      reason: item.reason
    };
  }

  approve(id: string) { this.leave.approve(id); }
  reject(id: string) { this.leave.reject(id); }
  remove(id: string) { this.leave.delete(id); }

  reset(f?: NgForm) {
    this.form = { employeeName: '', type: 'Vacation', startDate: '', endDate: '', reason: '' };
    f?.resetForm({ ...this.form });
    this.dateError = null;
  }

  trackById(_: number, it: LeaveRequest) { return it.id; }
}
