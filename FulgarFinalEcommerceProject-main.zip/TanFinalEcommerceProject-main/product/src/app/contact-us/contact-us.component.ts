import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  standalone: false,
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
  submitted = false;

  onSubmit(form: any) {
    if (!form?.valid) { return; }
    this.submitted = true;
    // no backend yet; keep it friendly and simple
    setTimeout(() => this.submitted = false, 4000);
  }
}
