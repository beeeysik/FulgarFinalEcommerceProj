import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../service/product.service';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  product: any;
  quantity = 1;

  constructor(private route: ActivatedRoute, private router: Router, private products: ProductService, private cart: CartService) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!Number.isFinite(id)) { this.router.navigate(['/catalog']); return; }
    this.products.getById(id).subscribe(p => this.product = p);
  }

  addToCart() {
    if (!this.product) return;
    const item = {
      productId: this.product.id,
      productName: this.product.name,
      productDescription: this.product.description,
      productCategoryName: this.product.categoryName,
      productImageFile: this.product.imageFile,
      productUnitOfMeasure: this.product.unitOfMeasure,
      quantity: this.quantity,
      price: Number(this.product.price)
    };
    this.cart.addItem(item).subscribe(() => this.router.navigate(['/cart']));
  }
}
