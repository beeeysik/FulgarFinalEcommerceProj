export type LeaveStatus = 'Pending' | 'Approved' | 'Rejected';
export type LeaveType = 'Vacation' | 'Sick' | 'Unpaid' | 'Other';

export interface LeaveRequest {
  id: string;
  employeeName: string;
  type: LeaveType;
  startDate: string; // ISO date (yyyy-mm-dd)
  endDate: string;   // ISO date (yyyy-mm-dd)
  reason: string;
  status: LeaveStatus;
  createdAt: number; // epoch ms
  updatedAt: number; // epoch ms
}
