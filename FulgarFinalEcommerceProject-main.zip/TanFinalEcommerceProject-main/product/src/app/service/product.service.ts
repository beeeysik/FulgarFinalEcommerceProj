import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProductService extends BaseHttpService {
  constructor(protected override http: HttpClient) {
    super(
      http,
      environment.useAssets ? '/assets/product.json' : '/api/product'
    );
  }

  protected override requestData(): Observable<any> {
    if (environment.useAssets) {
      return this.http.get('assets/product.json').pipe(map(r => r));
    }
    return super.requestData();
  }

  getById(id: number) {
    if (environment.useAssets) {
      return this.http.get<any>('assets/product.json').pipe(
        map((groups: any[]) => {
          const all = (groups || []).flatMap((g: any) => g.products || []);
          return all.find((p: any) => Number(p.id) === Number(id));
        })
      );
    }
    return this.http.get<any>(this.apiServerUrl + `/api/product/${id}`);
  }
}
