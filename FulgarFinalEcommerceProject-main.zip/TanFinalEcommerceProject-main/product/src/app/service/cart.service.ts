import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private readonly STORAGE_KEY = 'cart_items';
  constructor(private http?: HttpClient) {}

  private getItems(): any[] {
    const items = localStorage.getItem(this.STORAGE_KEY);
    return items ? JSON.parse(items) : [];
  }

  private saveItems(items: any[]): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(items));
  }

  list(): Observable<any[]> {
    const apiBase = environment.apiBaseUrl;
    if (apiBase && this.http) {
      return this.http.get<any[]>(`${apiBase}/api/order`).pipe(
        map(res => (res && res.length ? res : this.getItems())),
        catchError(() => of(this.getItems()))
      );
    }
    return of(this.getItems());
  }

  addItem(item: any): Observable<any> {
    const items = this.getItems();
    // Generate a unique ID for the item
    item.id = Date.now();
    items.push(item);
    this.saveItems(items);
    return of(item);
  }

  updateItem(item: any): Observable<any> {
    const items = this.getItems();
    const index = items.findIndex(i => i.id === item.id);
    if (index !== -1) {
      items[index] = item;
      this.saveItems(items);
    }
    return of(item);
  }

  remove(id: number): Observable<void> {
    const doRemoveLocal = () => {
      const items = this.getItems().filter(item => item.id !== id);
      this.saveItems(items);
    };

    // If backend API is configured, attempt to delete there as well
    const apiBase = environment.apiBaseUrl;
    if (apiBase && this.http) {
      return this.http.delete<void>(`${apiBase}/api/order/${id}`).pipe(
        map(() => {
          doRemoveLocal();
          return void 0 as void;
        }),
        catchError(err => {
          // If backend delete fails, still remove locally
          doRemoveLocal();
          return of(void 0);
        })
      );
    }

    doRemoveLocal();
    return of(void 0);
  }

  /**
   * Clear only the client-side localStorage cart (does not call backend).
   */
  clearLocal(): Observable<void> {
    localStorage.removeItem(this.STORAGE_KEY);
    return of(void 0);
  }
}
