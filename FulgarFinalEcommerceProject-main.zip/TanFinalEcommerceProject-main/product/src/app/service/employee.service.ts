import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../model/employee';

@Injectable({ providedIn: 'root' })
export class EmployeeService {
  private readonly subject = new BehaviorSubject<Employee[]>([]);
  private loaded = false;

  constructor(private http: HttpClient) {}

  private refresh() {
    this.http.get<Employee[]>('/api/employee')
      .subscribe({ next: (list) => this.subject.next(list), error: () => this.subject.next([]) });
  }

  getAll(): Observable<Employee[]> {
    if (!this.loaded) {
      this.loaded = true;
      this.refresh();
    }
    return this.subject.asObservable();
  }

  add(employee: Omit<Employee, 'id'>): void {
    this.http.put<Employee>('/api/employee', employee)
      .subscribe(() => this.refresh());
  }

  update(updated: Employee): void {
    this.http.post<Employee>('/api/employee', updated)
      .subscribe(() => this.refresh());
  }

  delete(id: number): void {
    this.http.delete(`/api/employee/${id}`)
      .subscribe(() => this.refresh());
  }
}
