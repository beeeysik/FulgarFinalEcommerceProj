import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

export type ThemeName = 'light' | 'dark';

const STORAGE_KEY = 'theme';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  constructor(@Inject(DOCUMENT) private document: Document) {}

  init() {
    const stored = (localStorage.getItem(STORAGE_KEY) as ThemeName | null);
    // Default to light unless the user explicitly chose a theme
    const theme: ThemeName = stored ?? 'light';
    this.applyTheme(theme);
  }

  get current(): ThemeName {
    return (this.document.documentElement.getAttribute('data-theme') as ThemeName) || 'light';
  }

  setTheme(theme: ThemeName) {
    localStorage.setItem(STORAGE_KEY, theme);
    this.applyTheme(theme);
  }

  toggle(): ThemeName {
    const next: ThemeName = this.current === 'dark' ? 'light' : 'dark';
    this.setTheme(next);
    return next;
  }

  private applyTheme(theme: ThemeName) {
    this.document.documentElement.setAttribute('data-theme', theme);
  }
}
