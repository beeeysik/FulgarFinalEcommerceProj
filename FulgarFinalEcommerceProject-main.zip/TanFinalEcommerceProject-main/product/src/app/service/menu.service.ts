import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MenuService extends BaseHttpService {

  constructor(protected override http: HttpClient) {
    super(http, '/api/menu');
  }

  protected override requestData(): Observable<any> {
    if (environment.useAssets) {
      return this.http.get('assets/menu.json').pipe(map(r => r));
    }
    return super.requestData();
  }
}
