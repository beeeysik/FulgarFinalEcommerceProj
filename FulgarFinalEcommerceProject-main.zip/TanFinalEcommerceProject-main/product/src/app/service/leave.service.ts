import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { LeaveRequest, LeaveStatus, LeaveType } from '../model/leave';

type ApiLeave = {
  id: number;
  employeeId: number;
  employeeName: string;
  type: LeaveType;
  startDate: string | Date;
  endDate: string | Date;
  reason: string;
  status: LeaveStatus;
  created?: string | Date;
  lastUpdated?: string | Date;
};

@Injectable({ providedIn: 'root' })
export class LeaveService {
  private readonly subject = new BehaviorSubject<LeaveRequest[]>([]);
  readonly leaves$ = this.subject.asObservable();
  private loaded = false;

  constructor(private http: HttpClient) {}

  private toUi(a: ApiLeave): LeaveRequest {
    const toDateStr = (d?: string | Date) => {
      const dt = d ? new Date(d) : undefined;
      if (!dt || isNaN(dt.getTime())) return '';
      const yyyy = dt.getFullYear();
      const mm = String(dt.getMonth() + 1).padStart(2, '0');
      const dd = String(dt.getDate()).padStart(2, '0');
      return `${yyyy}-${mm}-${dd}`;
    };
    const toEpoch = (d?: string | Date) => {
      const dt = d ? new Date(d) : undefined;
      return dt && !isNaN(dt.getTime()) ? dt.getTime() : Date.now();
    };
    return {
      id: String(a.id),
      employeeName: a.employeeName,
      type: a.type,
      startDate: toDateStr(a.startDate),
      endDate: toDateStr(a.endDate),
      reason: a.reason,
      status: a.status,
      createdAt: toEpoch(a.created),
      updatedAt: toEpoch(a.lastUpdated)
    };
  }

  private toApi(u: Partial<LeaveRequest>): Partial<ApiLeave> {
    const parseDate = (s?: string) => (s ? new Date(s) : undefined);
    return {
      id: u.id != null ? Number(u.id) : undefined as any,
      employeeName: u.employeeName,
      type: u.type,
      startDate: parseDate(u.startDate),
      endDate: parseDate(u.endDate),
      reason: u.reason,
      status: u.status
    } as Partial<ApiLeave>;
  }

  private refresh() {
    this.http.get<ApiLeave[]>('/api/leave')
      .subscribe({ next: (list) => this.subject.next(list.map(this.toUi)), error: () => this.subject.next([]) });
  }

  list(): Observable<LeaveRequest[]> {
    if (!this.loaded) {
      this.loaded = true;
      this.refresh();
    }
    return this.leaves$;
  }

  add(data: Omit<LeaveRequest, 'id' | 'status' | 'createdAt' | 'updatedAt'>): void {
    const payload = this.toApi({ ...data, status: 'Pending' });
    this.http.put<ApiLeave>('/api/leave', payload)
      .subscribe(() => this.refresh());
  }

  update(id: string, patch: Partial<LeaveRequest>): void {
    // merge against existing to ensure id is included
    const current = this.subject.value.find(x => x.id === id);
    if (!current) return;
    const merged = { ...current, ...patch } as LeaveRequest;
    const payload = this.toApi(merged) as ApiLeave;
    this.http.post<ApiLeave>('/api/leave', payload)
      .subscribe(() => this.refresh());
  }

  setStatus(id: string, status: LeaveStatus) { this.update(id, { status }); }
  approve(id: string) { this.setStatus(id, 'Approved'); }
  reject(id: string) { this.setStatus(id, 'Rejected'); }

  delete(id: string): void {
    const numId = Number(id);
    if (!Number.isFinite(numId)) return;
    this.http.delete(`/api/leave/${numId}`)
      .subscribe(() => this.refresh());
  }

  search(term: string): Observable<LeaveRequest[]> {
    const q = term.trim().toLowerCase();
    return this.leaves$.pipe(map(list => !q ? list : list.filter(it =>
      it.employeeName.toLowerCase().includes(q) ||
      it.type.toLowerCase().includes(q) ||
      it.status.toLowerCase().includes(q) ||
      it.reason.toLowerCase().includes(q)
    )));
  }
}
