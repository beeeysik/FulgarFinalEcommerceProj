package com.gabriel.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.gabriel.enums.LeaveStatus;
import com.gabriel.enums.LeaveType;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "employee_leave_data")
public class EmployeeLeaveData {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    private int employeeId;
    private String employeeName;

    @Enumerated(EnumType.STRING)
    private LeaveType type;

    @Temporal(TemporalType.DATE)
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+08:00")
    private Date startDate;

    @Temporal(TemporalType.DATE)
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+08:00")
    private Date endDate;

    private String reason;

    @Enumerated(EnumType.STRING)
    private LeaveStatus status;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+08:00")
    private Date lastUpdated;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+08:00")
    private Date created;
}
