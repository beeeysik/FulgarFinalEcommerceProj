package com.gabriel.controller;

import com.gabriel.model.Employee;
import com.gabriel.service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/api/employee")
    public ResponseEntity<?> getAll() {
        try {
            List<Employee> list = employeeService.getAll();
            return ResponseEntity.ok(list);
        } catch (Exception ex) {
            log.error("Failed to retrieve employees: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @GetMapping("/api/employee/{id}")
    public ResponseEntity<?> get(@PathVariable Integer id) {
        try {
            Employee e = employeeService.get(id);
            return ResponseEntity.ok(e);
        } catch (Exception ex) {
            log.error("Failed to retrieve employee: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @PutMapping("/api/employee")
    public ResponseEntity<?> add(@RequestBody Employee employee) {
        try {
            Employee created = employeeService.create(employee);
            return ResponseEntity.ok(created);
        } catch (Exception ex) {
            log.error("Failed to create employee: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @PostMapping("/api/employee")
    public ResponseEntity<?> update(@RequestBody Employee employee) {
        try {
            Employee updated = employeeService.update(employee);
            return ResponseEntity.ok(updated);
        } catch (Exception ex) {
            log.error("Failed to update employee: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @DeleteMapping("/api/employee/{id}")
    public ResponseEntity<?> delete(@PathVariable Integer id) {
        try {
            employeeService.delete(id);
            return ResponseEntity.ok().build();
        } catch (Exception ex) {
            log.error("Failed to delete employee: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }
}
