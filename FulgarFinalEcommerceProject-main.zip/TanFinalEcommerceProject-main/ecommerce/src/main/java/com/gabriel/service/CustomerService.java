package com.gabriel.service;

public interface CustomerService {

}
