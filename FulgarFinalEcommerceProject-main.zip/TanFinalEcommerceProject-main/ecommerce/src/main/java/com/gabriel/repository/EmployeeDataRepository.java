package com.gabriel.repository;

import com.gabriel.entity.EmployeeData;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeDataRepository extends CrudRepository<EmployeeData, Integer> {
}
