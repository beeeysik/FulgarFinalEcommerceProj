package com.gabriel.serviceimpl;

import com.gabriel.entity.EmployeeData;
import com.gabriel.model.Employee;
import com.gabriel.repository.EmployeeDataRepository;
import com.gabriel.service.EmployeeService;
import com.gabriel.util.Transform;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeDataRepository employeeDataRepository;

    private final Transform<EmployeeData, Employee> toModel = new Transform<>(Employee.class);
    private final Transform<Employee, EmployeeData> toEntity = new Transform<>(EmployeeData.class);

    @Override
    public List<Employee> getAll() {
        List<EmployeeData> records = new ArrayList<>();
        List<Employee> result = new ArrayList<>();
        employeeDataRepository.findAll().forEach(records::add);
        Iterator<EmployeeData> it = records.iterator();
        while (it.hasNext()) {
            EmployeeData data = it.next();
            result.add(toModel.transform(data));
        }
        return result;
    }

    @Override
    public Employee get(Integer id) {
        Optional<EmployeeData> optional = employeeDataRepository.findById(id);
        return optional.map(toModel::transform).orElse(null);
    }

    @Override
    public Employee create(Employee employee) {
        EmployeeData saved = employeeDataRepository.save(toEntity.transform(employee));
        return toModel.transform(saved);
    }

    @Override
    public Employee update(Employee employee) {
        Optional<EmployeeData> optional = employeeDataRepository.findById(employee.getId());
        if (optional.isPresent()) {
            EmployeeData saved = employeeDataRepository.save(toEntity.transform(employee));
            return toModel.transform(saved);
        }
        log.error("Employee record with id {} does not exist", employee.getId());
        return null;
    }

    @Override
    public void delete(Integer id) {
        Optional<EmployeeData> optional = employeeDataRepository.findById(id);
        optional.ifPresent(employeeDataRepository::delete);
    }
}
