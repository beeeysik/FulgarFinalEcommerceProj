package com.gabriel.model;

public class AppDetail {
    int id;
    String name;
    String description;
}
