package com.gabriel.model;

import com.gabriel.enums.LeaveStatus;
import com.gabriel.enums.LeaveType;
import lombok.Data;

import java.util.Date;

@Data
public class EmployeeLeave {
    private int id;
    private int employeeId;
    private String employeeName;
    private LeaveType type;
    private Date startDate;
    private Date endDate;
    private String reason;
    private LeaveStatus status;
    private Date created;
    private Date lastUpdated;
}
