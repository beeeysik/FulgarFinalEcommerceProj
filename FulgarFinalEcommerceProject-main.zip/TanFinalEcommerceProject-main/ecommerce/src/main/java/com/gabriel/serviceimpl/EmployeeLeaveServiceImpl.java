package com.gabriel.serviceimpl;

import com.gabriel.entity.EmployeeLeaveData;
import com.gabriel.model.EmployeeLeave;
import com.gabriel.repository.EmployeeLeaveDataRepository;
import com.gabriel.service.EmployeeLeaveService;
import com.gabriel.util.Transform;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class EmployeeLeaveServiceImpl implements EmployeeLeaveService {

    @Autowired
    private EmployeeLeaveDataRepository employeeLeaveDataRepository;

    private final Transform<EmployeeLeaveData, EmployeeLeave> toModel = new Transform<>(EmployeeLeave.class);
    private final Transform<EmployeeLeave, EmployeeLeaveData> toEntity = new Transform<>(EmployeeLeaveData.class);

    @Override
    public List<EmployeeLeave> getAll() {
        List<EmployeeLeaveData> records = new ArrayList<>();
        List<EmployeeLeave> result = new ArrayList<>();
        employeeLeaveDataRepository.findAll().forEach(records::add);
        Iterator<EmployeeLeaveData> it = records.iterator();
        while (it.hasNext()) {
            EmployeeLeaveData data = it.next();
            result.add(toModel.transform(data));
        }
        return result;
    }

    @Override
    public List<EmployeeLeave> getByEmployeeId(Integer employeeId) {
        List<EmployeeLeaveData> records = employeeLeaveDataRepository.findAllByEmployeeId(employeeId);
        List<EmployeeLeave> result = new ArrayList<>();
        for (EmployeeLeaveData data : records) {
            result.add(toModel.transform(data));
        }
        return result;
    }

    @Override
    public EmployeeLeave get(Integer id) {
        Optional<EmployeeLeaveData> optional = employeeLeaveDataRepository.findById(id);
        return optional.map(toModel::transform).orElse(null);
    }

    @Override
    public EmployeeLeave create(EmployeeLeave leave) {
        EmployeeLeaveData saved = employeeLeaveDataRepository.save(toEntity.transform(leave));
        return toModel.transform(saved);
    }

    @Override
    public EmployeeLeave update(EmployeeLeave leave) {
        Optional<EmployeeLeaveData> optional = employeeLeaveDataRepository.findById(leave.getId());
        if (optional.isPresent()) {
            EmployeeLeaveData saved = employeeLeaveDataRepository.save(toEntity.transform(leave));
            return toModel.transform(saved);
        }
        log.error("EmployeeLeave record with id {} does not exist", leave.getId());
        return null;
    }

    @Override
    public void delete(Integer id) {
        Optional<EmployeeLeaveData> optional = employeeLeaveDataRepository.findById(id);
        optional.ifPresent(employeeLeaveDataRepository::delete);
    }
}
