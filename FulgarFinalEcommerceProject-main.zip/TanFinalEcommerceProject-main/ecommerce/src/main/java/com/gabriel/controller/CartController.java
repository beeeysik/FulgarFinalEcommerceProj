package com.gabriel.controller;

import com.gabriel.enums.OrderItemStatus;
import com.gabriel.model.OrderItem;
import com.gabriel.service.OrderItemService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class CartController {

    @Autowired
    private OrderItemService orderItemService;

    private String sessionId(HttpSession session) { return session.getId(); }

    @GetMapping("/api/cart")
    public ResponseEntity<?> getCart(HttpSession session) {
        try {
            List<OrderItem> items = orderItemService.getCartItems(sessionId(session));
            return ResponseEntity.ok(items);
        } catch (Exception ex) {
            log.error("Failed to fetch cart: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @PutMapping("/api/cart")
    public ResponseEntity<?> addItem(HttpSession session, @RequestBody OrderItem item) {
        try {
            item.setSessionId(sessionId(session));
            item.setStatus(OrderItemStatus.Created);
            OrderItem created = orderItemService.create(item);
            return ResponseEntity.ok(created);
        } catch (Exception ex) {
            log.error("Failed to add to cart: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @PostMapping("/api/cart")
    public ResponseEntity<?> updateItem(HttpSession session, @RequestBody OrderItem item) {
        try {
            item.setSessionId(sessionId(session));
            OrderItem updated = orderItemService.update(item);
            return ResponseEntity.ok(updated);
        } catch (Exception ex) {
            log.error("Failed to update cart item: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @DeleteMapping("/api/cart/{id}")
    public ResponseEntity<?> removeItem(@PathVariable Integer id) {
        try {
            orderItemService.delete(id);
            return ResponseEntity.ok().build();
        } catch (Exception ex) {
            log.error("Failed to remove cart item: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }
}
