package com.gabriel.controller;

import com.gabriel.entity.OrderItemData;
import com.gabriel.model.Order;
import com.gabriel.model.OrderItem;
import com.gabriel.repository.OrderItemDataRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.dao.EmptyResultDataAccessException;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/order")
@CrossOrigin(origins = "*")
public class OrderController {

    private final OrderItemDataRepository repository;

    public OrderController(OrderItemDataRepository repository) {
        this.repository = repository;
    }

    @PostMapping
    public ResponseEntity<?> createOrder(@RequestBody Order order) {
        if (order == null || order.getItems() == null || order.getItems().isEmpty()) {
            return ResponseEntity.badRequest().body("Order must contain at least one item");
        }

        List<OrderItemData> saved = new ArrayList<>();
        for (OrderItem it : order.getItems()) {
            OrderItemData d = new OrderItemData();
            d.setOrderId(it.getOrderId());
            d.setCustomerId(it.getCustomerId());
            d.setSessionId(it.getSessionId());
            d.setCustomerName(it.getCustomerName());
            d.setProductId(it.getProductId());
            d.setProductName(it.getProductName());
            d.setProductDescription(it.getProductDescription());
            d.setProductCategoryName(it.getProductCategoryName());
            d.setProductImageFile(it.getProductImageFile());
            d.setProductUnitOfMeasure(it.getProductUnitOfMeasure());
            d.setQuantity(it.getQuantity());
            d.setPrice(it.getPrice());
            d.setStatus(it.getStatus());
            saved.add(repository.save(d));
        }

        return ResponseEntity.ok(saved);
    }

    @PutMapping
    public ResponseEntity<?> createOrderPut(@RequestBody Order order) {
        return createOrder(order);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteOrderItem(@PathVariable Integer id) {
        try {
            repository.deleteById(id);
        } catch (EmptyResultDataAccessException ex) {
            // ignore if not found
        }
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<OrderItemData>> listAll() {
        List<OrderItemData> all = new ArrayList<>();
        repository.findAll().forEach(all::add);
        return ResponseEntity.ok(all);
    }
}

