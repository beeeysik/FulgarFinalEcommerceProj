package com.gabriel.repository;

import com.gabriel.entity.EmployeeLeaveData;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EmployeeLeaveDataRepository extends CrudRepository<EmployeeLeaveData, Integer> {
    List<EmployeeLeaveData> findAllByEmployeeId(Integer employeeId);
}
