package com.gabriel.entity;

public class AppDetailsData
{

}
