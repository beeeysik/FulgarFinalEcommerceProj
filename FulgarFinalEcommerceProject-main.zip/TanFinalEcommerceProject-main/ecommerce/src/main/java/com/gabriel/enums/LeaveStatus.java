package com.gabriel.enums;

public enum LeaveStatus {
    Pending,
    Approved,
    Rejected
}
