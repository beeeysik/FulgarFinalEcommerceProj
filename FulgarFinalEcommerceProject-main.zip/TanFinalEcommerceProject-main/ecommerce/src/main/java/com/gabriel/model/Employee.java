package com.gabriel.model;

import lombok.Data;

import java.util.Date;

@Data
public class Employee {
    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String position;
    private Date created;
    private Date lastUpdated;
}
