package com.gabriel.service;

import com.gabriel.model.EmployeeLeave;

import java.util.List;

public interface EmployeeLeaveService {
    List<EmployeeLeave> getAll();
    List<EmployeeLeave> getByEmployeeId(Integer employeeId);
    EmployeeLeave get(Integer id);
    EmployeeLeave create(EmployeeLeave leave);
    EmployeeLeave update(EmployeeLeave leave);
    void delete(Integer id);
}
