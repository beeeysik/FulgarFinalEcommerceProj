package com.gabriel.entity;

public class CatagoryData {
}
