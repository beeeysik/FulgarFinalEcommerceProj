package com.gabriel.controller;

import com.gabriel.model.EmployeeLeave;
import com.gabriel.service.EmployeeLeaveService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class EmployeeLeaveController {

    @Autowired
    private EmployeeLeaveService employeeLeaveService;

    @GetMapping("/api/leave")
    public ResponseEntity<?> getAll(@RequestParam(value = "employeeId", required = false) Integer employeeId) {
        try {
            List<EmployeeLeave> list = (employeeId == null)
                    ? employeeLeaveService.getAll()
                    : employeeLeaveService.getByEmployeeId(employeeId);
            return ResponseEntity.ok(list);
        } catch (Exception ex) {
            log.error("Failed to retrieve leaves: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @GetMapping("/api/leave/{id}")
    public ResponseEntity<?> get(@PathVariable Integer id) {
        try {
            EmployeeLeave e = employeeLeaveService.get(id);
            return ResponseEntity.ok(e);
        } catch (Exception ex) {
            log.error("Failed to retrieve leave: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @PutMapping("/api/leave")
    public ResponseEntity<?> add(@RequestBody EmployeeLeave leave) {
        try {
            EmployeeLeave created = employeeLeaveService.create(leave);
            return ResponseEntity.ok(created);
        } catch (Exception ex) {
            log.error("Failed to create leave: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @PostMapping("/api/leave")
    public ResponseEntity<?> update(@RequestBody EmployeeLeave leave) {
        try {
            EmployeeLeave updated = employeeLeaveService.update(leave);
            return ResponseEntity.ok(updated);
        } catch (Exception ex) {
            log.error("Failed to update leave: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }

    @DeleteMapping("/api/leave/{id}")
    public ResponseEntity<?> delete(@PathVariable Integer id) {
        try {
            employeeLeaveService.delete(id);
            return ResponseEntity.ok().build();
        } catch (Exception ex) {
            log.error("Failed to delete leave: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
        }
    }
}
