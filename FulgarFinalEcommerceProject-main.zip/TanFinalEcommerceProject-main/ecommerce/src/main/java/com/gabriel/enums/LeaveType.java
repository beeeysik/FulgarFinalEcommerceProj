package com.gabriel.enums;

public enum LeaveType {
    Vacation,
    Sick,
    Unpaid,
    Other
}
