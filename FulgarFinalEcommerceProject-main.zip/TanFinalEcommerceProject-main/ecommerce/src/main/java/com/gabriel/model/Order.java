package com.gabriel.model;

import lombok.Data;

import java.util.List;

@Data
public class Order {
    int id;
    String customerId;
    List<OrderItem> items;
}
