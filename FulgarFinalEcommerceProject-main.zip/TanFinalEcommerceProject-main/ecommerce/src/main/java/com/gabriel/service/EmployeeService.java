package com.gabriel.service;

import com.gabriel.model.Employee;

import java.util.List;

public interface EmployeeService {
    List<Employee> getAll();
    Employee get(Integer id);
    Employee create(Employee employee);
    Employee update(Employee employee);
    void delete(Integer id);
}
