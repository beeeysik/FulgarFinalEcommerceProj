-- Schema for cart items persisted by OrderItemData JPA entity
CREATE TABLE IF NOT EXISTS order_item_data (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  orderId INT NULL,
  customerId INT NULL,
  sessionId VARCHAR(100) NULL,
  customerName VARCHAR(255) NULL,
  productId INT NULL,
  productName VARCHAR(255) NULL,
  productDescription VARCHAR(500) NULL,
  productCategoryName VARCHAR(255) NULL,
  productImageFile VARCHAR(255) NULL,
  productUnitOfMeasure VARCHAR(50) NULL,
  quantity DOUBLE NULL,
  price DOUBLE NULL,
  status INT NULL,
  lastUpdated DATETIME NULL,
  created DATETIME NULL,
  INDEX idx_sessionId (sessionId),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
